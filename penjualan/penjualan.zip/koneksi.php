<?php
//error_reporting(0);
session_start();
$connect = mysqli_connect('localhost','root','','penjualan');
$all_k = 0;
$all_k = mysqli_num_rows(mysqli_query($connect,"SELECT * FROM keranjang WHERE id_bayar='0'"));
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Coba-Coba</title>
    <link href="css/style.css" rel="stylesheet"/>
</head>
<body>
    <ul class="menu">
        <li><a href="index.php">Beranda</a></li>
        <li><a href="keranjang.php">Keranjang (<?php echo $all_k; ?>)</a></li>
    </ul>
