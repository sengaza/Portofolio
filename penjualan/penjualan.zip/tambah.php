<?php
include 'koneksi.php';

if($_SESSION['role']=='admin'){

if(isset($_POST['tambah'])){
    $n = $_POST['nama'];
    $al = $_POST['alamat'];
    $b = $_POST['barang'];
    $j = $_POST['jumlah'];
    $h = $_POST['hj'];
    $tlp = $_POST['tlp'];
    $hj = $_POST['hj'];
    $k = $_POST['ket'];

    mysqli_query($connect, "INSERT INTO suplier SET nama='$n',alamat='$al', barang='$b', jumlah='$j', harga='$h', tlp='$tlp'");
    mysqli_query($connect, "INSERT INTO barang SET nama='$b', jumlah='$j', harga='$hj', keterangan='$k'");
    header("Location: admin.php");


}
?>

<form action="tambah.php" method="post">
<table>
    <tr>
        <td>Nama Suplier</td>
        <td>:</td>
        <td><input type="text" name="nama"></td>
    </tr>
    <tr>
        <td>Alamat</td>
        <td>:</td>
        <td><input type="text" name="alamat"></td>
    </tr>
    <tr>
        <td>Barang</td>
        <td>:</td>
        <td><input type="text" name="barang"></td>
    </tr>
    <tr>
        <td>Jumlah</td>
        <td>:</td>
        <td><input type="text" name="jumlah"></td>
    </tr>
    <tr>
        <td>Harga Suplier</td>
        <td>:</td>
        <td><input type="text" name="hs"> </td>
    </tr>
    <tr>
        <td>Tlp</td>
        <td>:</td>
        <td><input type="text" name="tlp" ></td>
    </tr>
    <tr>
        <td>Harga Jual</td>
        <td>:</td>
        <td><input type="text" name="hj"> </td>
    </tr>
    <tr>
        <td>Keterang</td>
        <td>:</td>
        <td><input type="text" name="ket"></td>
    </tr>
</table>
<input type="submit" name="tambah" value="Tambah">
<a href="admin.php"><button>Batal</button></a>
</form>
<?php
}else{
    header("Location: login.php");
}
?>