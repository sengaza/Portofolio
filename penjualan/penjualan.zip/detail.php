<?php
include 'koneksi.php';

$id = $_GET['id'];
$hasil = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM barang WHERE id='$id'"));
if($hasil['nama']) {
    $id = $hasil['id'];
    $n = $hasil['nama'];
    $j = $hasil['jumlah'];
    $r = $hasil['rating'];
    $h = $hasil['harga'];
    $t = $hasil['terjual'];
    $k = $hasil['keterangan'];

    echo "<div class='single-item'>
        <h2>$n</h2>
        <img src='image/$id.jpg'/>
        <p>$k</p>
        <span>Stock: $j</span><br>
        <span>Rp $h</span><br>
        <span>Rating: ".round($r,1)."/5</span><br>
        <span>Terjual: $t</span><br><br>
        Rate: ";
        for ($i=1; $i <= 5; $i++) { 
            echo "<a class='star' href='rate.php?id=$id&nilai=$i'><button>*</button></a> ";
        }
        echo " - - - - - <a href='keranjang.php?add=$id'/><button>Beli</button></a></div>";
}
?>