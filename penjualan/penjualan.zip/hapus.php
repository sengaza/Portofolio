<?php
include 'koneksi.php';
$id = $_GET['id'];
$tabel = $_GET['tabel'];
if(isset($_POST['hapus'])){
    mysqli_query($connect, "DELETE FROM $tabel WHERE id='$id'");
    header("Location: admin.php");
}
?>
<style>
    table{
        margin:auto;
        padding:20px;
        border:1px solid black;
    }
    
</style>
<form action="hapus.php?tabel=<?php echo $tabel?>&id=<?php echo $id ?>" method="post">
    <table>
        <tr>
            <td colspan="2"><p>Apakah Anda Yakin?</p></td>
        </tr>
        <tr>
            <td><input type="submit" name="hapus" value="Hapus"></td>
            <td><input type="submit" name="batal" value="Batal"></td>
        </tr>
    </table>
</form>
