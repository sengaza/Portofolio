<?php
include 'koneksi.php';
if(isset($_GET['add'])) {
    $id = $_GET['add'];
    $hasil = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM barang WHERE id='$id'"));
    if($hasil['nama']) {
        $id = $hasil['id'];
        $n = $hasil['nama'];
        $j = $hasil['jumlah'];
        echo "
        <h2>$n</h2>
        <form action='keranjang.php' method='post'>
            <input type='hidden' name='id' value='$id'/>    
            Jumlah:<br><input type='text' name='jumlah'> (tersedia: $j)<br><br>
            Keterangan:<br><textarea name='ket'></textarea><br><br>
            <button name='beli'>Tambah ke kranjang</button>    
        </form><br>
        <a href='detail.php?id=$id'><button>Kembali</button></a>
        ";
    }
} else {
    ?>
    <table border=1 width=100%>
        <tr> <th>No</th> <th>Nama</th> <th>Jumlah</th> <th>Keterangan</th> <th>Harga</th></tr>
    <?php
        $sql=mysqli_query($connect,"SELECT keranjang.*, barang.nama AS nama_b, barang.harga AS harga_b FROM keranjang,barang WHERE keranjang.id_barang=barang.id AND id_bayar='0'");
        if(mysqli_num_rows($sql)) {
            $i=1;
            $total = 0;
            while($keranjang = mysqli_fetch_assoc($sql)) {
                $n = $keranjang['nama_b'];
                $j = $keranjang['jumlah'];
                $k = $keranjang['keterangan'];
                $h = $keranjang['harga_b']*$j;
                $total +=$h;
                echo "<tr> <td>$i</td> <td>$n</td> <td>$j</td> <td>$k</td> <td>Rp $h</td> </tr>";
                $i++;
            }
            echo '
            <tr> <td colspan=4>Total</td><td>Rp '.$total.'</td></tr>
            </table><br><a href="pembayaran.php"><button>Bayar</button></a>';
        } else {
            echo '<tr><td colspan="5">Belum ada barang</td></tr>';
        }

}
if(isset($_POST['beli'])){
    $id = $_POST['id'];
    $j = $_POST['jumlah'];
    $k = $_POST['ket'];
    $get = mysqli_fetch_assoc(mysqli_query($connect,"SELECT harga FROM barang WHERE id='$id'"));
    $get_harga = $get['harga'];
    $h = $j*$get_harga;
    mysqli_query($connect,"INSERT INTO keranjang SET id_barang='$id', jumlah='$j', harga='$h', keterangan='$k'");
    //header('location: detail.php?id='.$id);

}
?>