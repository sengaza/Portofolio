<?php
include 'koneksi.php';

//if($_SESSION['role']=='admin'){
//$id =$_GET['id'];
if($_SESSION['role']=='admin'){

if(isset($_GET['status'])){
    $id = $_GET['id'];
    $krj = mysqli_query($connect, "SELECT * FROM keranjang WHERE id_bayar='$id'");
    while($kranjang = mysqli_fetch_assoc($krj)) {
        $j = $kranjang['jumlah'];
        $idb = $kranjang['id_barang'];
        mysqli_query($connect,"UPDATE barang SET jumlah=jumlah-$j, terjual=terjual+$j WHERE id='$idb'");
    }
    mysqli_query($connect, "UPDATE pembayaran SET status='lunas' WHERE id='$id'");
}

?>
    <h1>Tabel Barang</h1>
    <table border="1" width="100%">
        <tr> <th>No</th> <th>Nama</th> <th>Jumlah</th> <th>Harga</th> <th colspan="2">CRUD</th></tr>
    <?php
    $cek = mysqli_query($connect, "SELECT * FROM barang");
    $i = 1;
    while($hasil = mysqli_fetch_assoc($cek)){
        $id = $hasil['id'];
        $n = $hasil['nama'];
        $j = $hasil['jumlah'];
        $h = $hasil['harga'];
        echo "<tr> <td>$i</td> <td>$n</td> <td>$j</td> <td>$h</td>
        <td><a href='edit.php?id=$id'><button>Edit</button></a></td>
        <td><a href='hapus.php?tabel=barang&id=$id'><button>Delete</button></a></td>
        </tr>";
        $i++;
    }
    ?>
    </table><br><br>
    <h1>Tabel Suplier</h1>
    <table border="1" width="100%">
        <tr> <th>No</th> <th>Nama</th> <th>Alamat</th><th>Barang</th> <th>Jumlah</th><th>Harga</th><th>Telp</th> <th>CRUD</th></tr>
    <?php
    $cek = mysqli_query($connect, "SELECT * FROM suplier");
    $i = 1;
    while($hasil = mysqli_fetch_assoc($cek)){
        $id = $hasil['id'];
        $n = $hasil['nama'];
        $al = $hasil['alamat'];
        $b = $hasil['barang'];
        $j = $hasil['jumlah'];
        $h = $hasil['harga'];
        $tlp = $hasil['tlp'];
        echo "<tr> <td>$i</td> <td>$n</td> <td>$al</td> <td>$b</td> <td>$j</td> <td>$h</td><td>$tlp</td>
        <td><a href='hapus.php?tabel=pembayaran&id=$id'><button>Delete</button></a></td></tr>";               
        $i++;
    }
    ?>
    </table><br><br>
    <a href="tambah.php"><button type="button">Tambah</button></a>
    <h1>Tabel Pembayaran</h1>
    <table border="1" width="100%">
        <tr> <th>No</th> <th>Nama</th> <th>Alamat</th> <th>No.Hp</th><th>Total</th> <th>Status</th></tr>
    <?php
    $cek = mysqli_query($connect, "SELECT * FROM pembayaran");
    $i = 1;
    while($hasil = mysqli_fetch_assoc($cek)){
        $id = $hasil['id'];
        $n = $hasil['nama'];
        $al = $hasil['alamat'];
        $hp = $hasil['hp'];
        $t = $hasil['total'];   
        echo "<tr> <td>$i</td> <td>$n</td> <td>$al</td> <td>$hp</td><td>$t</td>";
        if(empty($hasil['status'])){
        echo "<td><a href='admin.php?status=lunas&id=$id'><button>Lunas</button></a></td>";
        } else {
            echo "<td>Sudah Bayar</td>";
        }
        echo "</tr>";
        $i++;
    }
    ?>
    </table><br><br>
    <a href="logut.php"><input type="button" name="logout" value="Log Out"></a>    
</body>
</html>
<?php
} elseif($_SESSION['role']=='anggota') {
    header('Location: index.php');
} else {
    header('location: login.php');
}
?>