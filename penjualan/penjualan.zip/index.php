<?php
include 'koneksi.php';

$cek = mysqli_query($connect, "SELECT * FROM barang");
while($hasil = mysqli_fetch_assoc($cek)){
    $id = $hasil['id'];
    $n = $hasil['nama'];
    $j = $hasil['jumlah'];
    $r = $hasil['rating'];
    $h = $hasil['harga'];
    $t = $hasil['terjual'];
    echo "<div class='item'>
    <img src='image/$id.jpg'/>
        <a href='detail.php?id=$id'><p>$n</p></a>
        <span>Stock: $j</span><br>
        <span>Harga: Rp $h</span><br>
        <span>Rating: ".round($r,1)."/5</span><br>
        <span>Terjual: $t</span>
    </div>";
}
?>

