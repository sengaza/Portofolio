<?php
include 'koneksi.php';

$id =$_GET['id']; //mengambil id di link
if($_SESSION['role']=='admin'){
$hasil = mysqli_query($connect, "SELECT * FROM barang WHERE id='$id'");
$anu = mysqli_fetch_assoc($hasil); //mengambil data berdasarkan nama kolom
$n = $anu['nama'];
$j = $anu['jumlah'];
$h = $anu['harga'];

if(isset($_POST['edit'])){
    $nb = $_POST['nama'];
    $s = $_POST['jumlah'];
    $hj = $_POST['harga'];

    mysqli_query($connect, "UPDATE barang SET nama='$nb', jumlah='$s', harga='$hj' WHERE id='$id'");
    header("Location: admin.php");
}
?>
<style>
    table{
        margin:auto;
        padding:20px;
        border:1px solid black;
    }
</style>
<form action="edit.php?id=<?php echo $id ?>" method="post"> <!-- menampilkan id di link -->
    <table>
        <tr>
            <td>Nama</td>
            <td>:</td>
            <td><input type="text" name="nama" value="<?php echo $n ?>"></td>
        </tr>
        <tr>
            <td>Jumlah</td>
            <td>:</td>
            <td><input type="text" name="jumlah" value="<?php echo $j ?>"></td>
        </tr>
        <tr>
            <td>Harga</td>
            <td>:</td>
            <td><input type="text" name="harga" value="<?php echo $h ?>"></td>
        </tr>
        <tr>
            <td><input type="submit" name="edit" value="Edit"></td>
            <td colspan="2"><a href="admin.php"><button>Batal</button></a></td>
        </tr>
    </table>
</form>
<?php
} else {
    echo "Silakan Login Terlebih Dahulu";
}
?>