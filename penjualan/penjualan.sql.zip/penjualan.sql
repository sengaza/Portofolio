-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Inang: 127.0.0.1
-- Waktu pembuatan: 15 Apr 2018 pada 19.53
-- Versi Server: 5.5.27
-- Versi PHP: 5.4.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Basis data: `penjualan`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `barang`
--

CREATE TABLE IF NOT EXISTS `barang` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `nama` varchar(30) NOT NULL,
  `jumlah` int(10) NOT NULL,
  `harga` varchar(30) NOT NULL,
  `keterangan` text NOT NULL,
  `rating` float NOT NULL,
  `terjual` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data untuk tabel `barang`
--

INSERT INTO `barang` (`id`, `nama`, `jumlah`, `harga`, `keterangan`, `rating`, `terjual`) VALUES
(1, 'Kursi Rotan', 48, '100000', 'Lorem ipsum dolor sit amet consectetur, adipisicing elit. Ad excepturi animi voluptatibus? Esse reiciendis in molestiae molestias voluptatem, soluta omnis ea eum laudantium officia odio, quas ratione? Repudiandae, reiciendis sapiente?', 3.5, 27),
(2, 'Meja Rotan', 55, '200000', 'Lorem ipsum dolor sit amet consectetur, adipisicing elit. Ad excepturi animi voluptatibus? Esse reiciendis in molestiae molestias voluptatem, soluta omnis ea eum laudantium officia odio, quas ratione? Repudiandae, reiciendis sapiente?', 3.231, 55),
(3, 'Lampu Kamar Rotan', 45, '50000', 'Lorem ipsum dolor sit amet consectetur, adipisicing elit. Ad excepturi animi voluptatibus? Esse reiciendis in molestiae molestias voluptatem, soluta omnis ea eum laudantium officia odio, quas ratione? Repudiandae, reiciendis sapiente?', 0, 27),
(4, 'Bola', 100, '15000', '', 0, 0),
(5, 'Mobil-Mobilan', 119, '50000', '', 0, 1),
(6, 'HP Mainan', 211, '26000', 'Lorem ipsum dolor sit amet consectetur, adipisicing elit. Ad excepturi animi voluptatibus? Esse reiciendis in molestiae molestias voluptatem, soluta omnis ea eum laudantium officia odio, quas ratione? Repudiandae, reiciendis sapiente?', 0, 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `keranjang`
--

CREATE TABLE IF NOT EXISTS `keranjang` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `id_barang` int(20) NOT NULL,
  `keterangan` varchar(30) NOT NULL,
  `jumlah` varchar(10) NOT NULL,
  `harga` int(11) NOT NULL,
  `id_bayar` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- Dumping data untuk tabel `keranjang`
--

INSERT INTO `keranjang` (`id`, `id_barang`, `keterangan`, `jumlah`, `harga`, `id_bayar`) VALUES
(7, 1, 'pink', '5', 0, 9),
(8, 2, 'ppink', '50', 0, 9),
(9, 1, 'pink', '3', 0, 10),
(10, 1, 'pink', '4', 0, 11),
(11, 1, 'pink', '4', 0, 11),
(12, 5, 'truk', '8', 0, 11),
(13, 4, 'Bola semangka', '10', 0, 12),
(14, 6, 'Hape Nokia', '10', 0, 12),
(15, 3, 'test', '10', 500000, 13),
(16, 5, 'khksx', '1', 50000, 13),
(17, 1, 'kadgcefc', '2', 200000, 13);

-- --------------------------------------------------------

--
-- Struktur dari tabel `pembayaran`
--

CREATE TABLE IF NOT EXISTS `pembayaran` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(32) NOT NULL,
  `alamat` varchar(200) NOT NULL,
  `hp` varchar(15) NOT NULL,
  `total` int(11) NOT NULL,
  `status` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data untuk tabel `pembayaran`
--

INSERT INTO `pembayaran` (`id`, `nama`, `alamat`, `hp`, `total`, `status`) VALUES
(9, '1', 'rumah aja', '09876543', 300000, ''),
(10, '1', 'rumah aja', '112233', 400000, ''),
(11, 'Hendro', 'rumah aja', '098765', 650000, ''),
(12, 'Hendro', 'rumah aja', '27547324', 0, ''),
(13, 'sammmm', 'ksdgckegk', '236497', 750000, 'lunas');

-- --------------------------------------------------------

--
-- Struktur dari tabel `rating`
--

CREATE TABLE IF NOT EXISTS `rating` (
  `id_barang` int(11) NOT NULL,
  `nilai` int(11) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=20 ;

-- --------------------------------------------------------

--
-- Struktur dari tabel `suplier`
--

CREATE TABLE IF NOT EXISTS `suplier` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `nama` varchar(30) NOT NULL,
  `alamat` varchar(100) NOT NULL,
  `barang` varchar(20) NOT NULL,
  `jumlah` int(20) NOT NULL,
  `harga` int(11) NOT NULL,
  `tlp` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data untuk tabel `suplier`
--

INSERT INTO `suplier` (`id`, `nama`, `alamat`, `barang`, `jumlah`, `harga`, `tlp`) VALUES
(1, 'PT Adag Udug', 'Jakarta Timur', 'Kursi Rotan', 50, 45000, 85898765),
(2, 'PT Gemblung', 'Jakpus', 'Bola', 100, 15000, 212322222),
(3, 'PT Sengaza', 'Jakarta Barat', 'Mobil-Mobilan', 120, 50000, 21212121),
(4, 'PT Koplak', 'Jakarta Barat', 'HP Mainan', 211, 25000, 21123123),
(5, 'PT Adag Udug', 'Jakarta Timur', 'Lampu Kamar Rotan', 55, 40000, 85898765),
(6, 'PT Adag Udug', 'Jakarta Timur', 'Meja Rotan', 55, 150000, 85898765);

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `role` varchar(20) NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`username`, `password`, `role`) VALUES
('admin', 'admin', 'admin'),
('anggota', 'anggota', 'anggota');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
